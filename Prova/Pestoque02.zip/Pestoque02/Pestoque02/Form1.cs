﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] mes = new double[4, 4];

            double semana1 = 0;
            double semana2 = 0;
            double semana3 = 0;
            double semana4 = 0;

            double TotalProduto1 = 0;
            double Total = 0;


            string auxiliar = "";

            for (int i = 0; i < mes.GetLength(0); i++)
            {
                for (int j = 0; j < mes.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"produto {i + 1}", $"semana {j + 1}");

                    if (!double.TryParse(auxiliar, out mes[i, j]) || mes[i, j] < 0)
                    {
                        MessageBox.Show("Dado inválido");

                        j--;
                    }
                    else
                    {
                        if (j == 0)
                        {
                            semana1 = Convert.ToDouble(auxiliar);
                        }
                        if (j == 1)
                        {
                            semana2 = Convert.ToDouble(auxiliar);
                        }
                        if (j == 2)
                        {
                            semana3 = Convert.ToDouble(auxiliar);
                        }
                        if (j == 3)
                        {
                            semana4 = Convert.ToDouble(auxiliar);
                        }

                        TotalProduto1 = semana1 + semana2 + semana3 + semana4;
                        Total = Total + TotalProduto1;

                    }

                }
                lstbxProdutos.Items.Add($"Total entradas do produto {i} semana 1 : {semana1}");
                lstbxProdutos.Items.Add($"Total entradas do produto {i} semana 2 : {semana2}");
                lstbxProdutos.Items.Add($"Total entradas do produto {i} semana 3 : {semana3}");
                lstbxProdutos.Items.Add($"Total entradas do produto {i} semana 4 : {semana4}");

                lstbxProdutos.Items.Add($"Total Entradas Produto {i} : {TotalProduto1}");

            }

            lstbxProdutos.Items.Add($"Total entrada : {Total}");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstbxProdutos.Items.Clear();
        }
    }
}
