﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void btnH_Click(object sender, EventArgs e)
        {
            double n;
            double h = 0;

            if (!Double.TryParse(txtN.Text, out n))
            {
                MessageBox.Show("Número inválido");
            }
            else
            {
                if (n <= 0)
                {
                    MessageBox.Show("Número deve ser maior que 0");
                }
                else
                {
                    for (int i = 1; i <= n; i++)
                    {
                        h += 1.0 / i;
                    }
                    MessageBox.Show($"valor de h: {h}");
                }
            }

        }
    }
}
