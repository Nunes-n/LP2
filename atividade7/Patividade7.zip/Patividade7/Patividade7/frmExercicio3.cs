﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string texto = txtTexto.Text;
            string textoCerto = texto.Replace(" ", "").ToUpper();

            char[] textoVetor = textoCerto.ToCharArray();
            Array.Reverse(textoVetor);
            string textoInvertd = new string(textoVetor);

            if (textoCerto == textoInvertd)
            {
                MessageBox.Show("É um palindromo");
            }
            else
            {
                MessageBox.Show("Não é um palindromo");
            }
        }
    }
}
