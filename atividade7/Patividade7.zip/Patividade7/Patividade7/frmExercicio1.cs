﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Patividade7
{
    public partial class frmExercicio1 : Form
    {
        int cont;
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnEspacos_Click(object sender, EventArgs e)
        {
            cont = 0;
            string texto = rchtxtTexto.Text;

            foreach (char c in texto)
            {
                if (c ==  ' ')
                {
                    cont += 1;
                }
            }

            MessageBox.Show($"{cont} espaços em branco");
        }

        private void btnR_Click(object sender, EventArgs e)
        {
            cont = 0;
            string texto = rchtxtTexto.Text.ToUpper();
            int i = 0;

            while (i < texto.Length)
            {
                if (texto[i] == 'R')
                {
                    cont += 1;
                }
                i += 1;
            }

            MessageBox.Show($"{cont} letras R");
        }

        private void btnPares_Click(object sender, EventArgs e)
        {
            cont = 0;
            string texto = rchtxtTexto.Text;

            for (int i = 0; i < texto.Length - 1; i++)
            {
                if (texto[i] == texto[i + 1])
                {
                    cont += 1;
                }
            }

            MessageBox.Show($"{cont} pares");
        }
    }
}
