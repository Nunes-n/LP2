﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnNumeros_Click(object sender, EventArgs e)
        {
            int cont = 0;
            int contNum = 0;

            while (cont < rchtxtFrase.Text.Length)
            {
                if (char.IsNumber(rchtxtFrase.Text[cont]))
                {
                    contNum++;
                }
                cont++;
            }

            MessageBox.Show($"{contNum} números");
        }

        private void btnBranco_Click(object sender, EventArgs e)
        {
            int cont = 0;

            for (int i = 0; !char.IsWhiteSpace(rchtxtFrase.Text[i]);i++)
            {
                cont++;
            }

            cont = cont + 1;

            MessageBox.Show($"Primeiro espaço em branco no endereço {cont}");
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int cont = 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    cont++;
                }
            }

            MessageBox.Show($"O texto possui {cont} letras");
        }
    }
}
