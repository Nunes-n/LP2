﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio5 : Form
    {
        double num1;
        double num2;
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtNum1.Text, out num1))||(!Double.TryParse(txtNum2.Text, out num2))||(num1 >= num2))
            {
                MessageBox.Show("Números inválidos");
                txtNum1.Focus();
            }
            else
            {
                int numero1 = (int)num1;
                int numero2 = (int)num2;
                Random objS = new Random();
                int x = objS.Next(numero1, numero2);
                MessageBox.Show(x.ToString());
            }
        }
    }
}
