﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract internal class Empregado
    {
        private int matriclua;//atrbuto
        private string nomeEmpregado;
        private DateTime dataEntradaEmpresa;

        public int Matricula // propriedade
        {
            get { return matriclua; }
            set { matriclua = value; }
        }
        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }
        public DateTime DataEntradaEmpresa // propriedade
        {
            get { return dataEntradaEmpresa; }
            set { dataEntradaEmpresa = value; }
        }
        public virtual int TempoTrabalho()//representa um intervalo de tempo virtual = dando autorização pra sobreescrever
        {
            TimeSpan span = DateTime.Today.Subtract(dataEntradaEmpresa);
            return (span.Days);
        }
        public abstract double SalarioBruto();

        public Empregado()
        {
            System.Windows.Forms.MessageBox.Show("aqui é empregado");
        }

    }
}

