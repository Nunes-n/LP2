﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string auxiliar = "";
            int[] tamanho = new int[10];
            string[] gigante = new string[10];

            for (int i = 0; i < nomes.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o nome {i + 1}", "Entrada de nomes");

                if (auxiliar == "")
                {
                    MessageBox.Show("Nome inválido");
                    i--;
                }
                else
                {
                    tamanho[i] = auxiliar.Replace(" ", "").Length;

                    gigante[i] ="\nO nome " + auxiliar + " tem " + tamanho[i] + " caracteres";
                }
            }

            for (int i = 0; i < gigante.Length; i++)
            {
                lstbxNomes.Items.Add(gigante[i]);
            }
        }
    }
}
