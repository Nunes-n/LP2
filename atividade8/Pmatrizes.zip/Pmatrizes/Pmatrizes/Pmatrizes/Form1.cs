﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < vetor.Length; i++) //entrada de dados
            {
                auxiliar = Interaction.InputBox($"Digite o número {i + 1}", "Entrada de dados");

                if (auxiliar == "")
                {
                    break;
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido");
                    i--;
                }
            }

            Array.Reverse(vetor); //inverte os dados

            auxiliar = "";
            foreach (int numero in vetor)
            {
                auxiliar += numero + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            ArrayList lista = new ArrayList();
            string auxiliar = "";

            lista.Add("Ana");
            lista.Add("André");
            lista.Add("Beatriz");
            lista.Add("Camila");
            lista.Add("João");
            lista.Add("Joana");
            lista.Add("Otávio");
            lista.Add("Marcelo");
            lista.Add("Pedro");
            lista.Add("Thais");

            foreach (string nome in lista)
            {
                if (nome != "Otávio")
                {
                    auxiliar += nome + "\n";
                }
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double[] medias = new double[20];


            for (int aluno = 0;  aluno < 20; aluno++)
            {
                for (int nota = 0; nota < 3;  nota++)
                {
                    auxiliar = Interaction.InputBox($"Nota {nota + 1}:", $"Aluno {aluno + 1}");

                    if (auxiliar == "")
                    {
                        break;
                    }

                    if (!Double.TryParse(auxiliar, out notas[aluno,nota]) || notas[aluno,nota] > 10 || notas[aluno,nota] < 0)
                    {
                        MessageBox.Show("Número invalido");
                        nota--;
                    }
                }

                medias[aluno] = (notas[aluno, 0] + notas[aluno, 1] + notas[aluno, 2]) / 3;
            }

            auxiliar = "";

            foreach (int j in medias)
            {
                auxiliar += j + "\n";
            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmExercicio4 obj4 = new frmExercicio4();
            obj4.WindowState = FormWindowState.Normal;
            obj4.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmExercicio5 obj5 = new frmExercicio5();
            obj5.WindowState = FormWindowState.Normal;
            obj5.Show();
        }
    }
}
