﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[] gabarito = {"A", "C", "B", "D", "A", "A", "E", "B", "D", "B"};
            string[,] respostas = new string[3, 10];
            string[,] resultado = new string[3, 10];
            string auxiliar = "";

            for (int i = 0; i < respostas.GetLength(0); i++)
            {
                for (int j = 0; j < respostas.GetLength(1); j++)
                {
                    auxiliar = Interaction.InputBox($"Resposta da questão {j + 1}", $"Aluno {i + 1}");

                    if ((auxiliar.ToUpper() == "A") || (auxiliar.ToUpper() == "B") || (auxiliar.ToUpper() == "C") || (auxiliar.ToUpper() == "D") || (auxiliar.ToUpper() == "E"))
                    {
                        if (auxiliar.ToUpper() == gabarito[j])
                        {
                            auxiliar = auxiliar.ToUpper();
                            resultado[i, j] = $"O aluno {i + 1} acertou a questão {j + 1}, era {gabarito[j]} escolheu {auxiliar}";
                        }
                        else
                        {
                            auxiliar = auxiliar.ToUpper();
                            resultado[i, j] = $"O aluno {i + 1} errou a questão {j + 1}, era {gabarito[j]} escolheu {auxiliar}";
                        }
                    }
                    else
                    {
                        MessageBox.Show("Resposta inválida");
                        j--;
                    }
                }
            }

            for (int i = 0;i < respostas.GetLength(0);i++)
            {
                for (int j = 0;j < respostas.GetLength(1);j++)
                {
                    lstbxRespostas.Items.Add(resultado[i,j]);
                }
            }
        }
    }
}
