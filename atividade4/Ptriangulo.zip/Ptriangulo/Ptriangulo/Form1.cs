﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double A, B, C;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtA.Text, out A))||(!Double.TryParse(txtB.Text, out B))||((!Double.TryParse(txtC.Text, out C))))
                {
                MessageBox.Show("Dados não são números");
                txtA.Focus();
                }
            else
            {
                if (((Math.Abs(B-C)<A)&&(A<(B+C)))&&((Math.Abs(A-C)<B)&&(B<(A+C)))&&((Math.Abs(A-B)<C)&&(C<(A+B))))
                {
                    if ((A == B) && (A == C) && (B == C))
                    {
                        MessageBox.Show("Triângulo equilátero");
                    }
                    else
                    {
                        if ((A != C) && (A != B) && (B != C))
                        {
                            MessageBox.Show("Triângulo escaleno");
                        }
                        else
                        {
                            MessageBox.Show("Triângulo Isósceles");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Números não podem ser lados de um triângulo");
                    txtA.Focus();
                }
            }
        }
    }
}
